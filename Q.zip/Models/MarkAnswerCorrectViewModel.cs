﻿namespace Q.Models
{
    public class MarkAnswerCorrectViewModel
    {
        public int QuestionId { get; set; }
        public List<Answer> Answers { get; set; }
    }
}
