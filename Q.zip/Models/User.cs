﻿using Microsoft.AspNetCore.Identity;

namespace Q.Models
{
    public class User : IdentityUser
    {
  
    }
}