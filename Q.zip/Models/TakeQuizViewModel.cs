﻿using Q.Models;

namespace Q.ViewModels
{
    public class TakeQuizViewModel
    {
        public Quiz Quiz { get; set; }
    }
}